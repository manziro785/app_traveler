import { api } from "@/src/shared/api/axiosInstance";
import { RouteType } from "../model/route.type";

export const fetchRoute = async (formData: RouteType) => {
  const res = await api.post("/routes/generate", formData);
  return res.data;
};
