import { useMutation } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import { fetchRoute } from "../api/route";
import { RouteType } from "./route.type";

export const useRouteCreate = () => {
  const router = useRouter();

  const handleSuccess = () => {
    router.push("/(tabs)");
  };

  const handleError = (error: unknown) => {
    const msg = error instanceof Error ? error.message : String(error);
    console.error(msg);
  };

  const routeCreateMutation = useMutation({
    mutationFn: (params: RouteType) => fetchRoute(params),
    onSuccess: handleSuccess,
    onError: handleError,
  });

  const submitRoute = async (formData: RouteType) => {
    return routeCreateMutation.mutateAsync(formData);
  };

  return {
    submitRoute,
    isLoading: routeCreateMutation.isPending,
  };
};
