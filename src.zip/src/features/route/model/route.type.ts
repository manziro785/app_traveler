export interface RouteType {
  location: string;
  scheduledDate: string;
  scheduledTime: string;
  duration: number;
  mood: [];
  budget: number;
  companions: string;
  transportation: string;
  mode: string;
}
