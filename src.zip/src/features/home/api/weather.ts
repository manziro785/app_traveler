import { api } from "@/src/shared/api/axiosInstance";

export const fetchWeather = async () => {
  const res = await api.get("/weather/recommendations?lat=42.8746&lng=74.5698");
  return res.data.data;
};
