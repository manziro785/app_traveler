import { useQuery } from "@tanstack/react-query";
import { fetchWeather } from "../api/weather";

const useGetWeatherQuery = () => {
  return useQuery({
    queryKey: ["weather"],
    queryFn: fetchWeather,
  });
};

export default useGetWeatherQuery;
