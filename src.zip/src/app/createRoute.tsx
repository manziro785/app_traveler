import { useRouter } from "expo-router";
import React, { useState } from "react";
import { ActivityIndicator, Alert, Text, View } from "react-native";
import { useRouteCreate } from "../features/route/model/useRoute";
import ProgressBar from "../features/route/ui/ProgressBar";
import Step1WhoAndHow from "./steps/Step1WhoAndHow";
import Step2TimeAvailable from "./steps/Step2TimeAvailable";
import Step3Location from "./steps/Step3Location";
import Step4Budget from "./steps/Step4Budget";
import Step5Preferences from "./steps/Step5Preferences";

interface FormData {
  companions: string | null;
  transportation: string | null;
  timeAvailable: string | null;
  location: string | null;
  budget: string | null;
  preferences: string[];
}

const COMPANIONS_MAP: Record<string, string> = {
  alone: "solo",
  couple: "couple",
  family: "family",
  company: "friends",
};

const TRANSPORT_MAP: Record<string, string> = {
  walking: "walking",
  car: "car",
  taxi: "car",
  public: "public_transport",
};

const TIME_MAP: Record<string, number> = {
  "2-3hours": 180,
  "half-day": 240,
  fullday: 480,
  weekend: 960,
};

const LOCATION_MAP: Record<string, string> = {
  bishkek: "Bishkek",
  "issyk-kul": "Issyk-Kul",
  karakol: "Karakol",
  osh: "Osh",
  naryn: "Naryn",
};

const BUDGET_MAP: Record<string, number> = {
  economy: 500,
  medium: 1500,
  comfort: 3000,
  unlimited: 5000,
};

export default function CreateRoute() {
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<FormData>({
    companions: null,
    transportation: null,
    timeAvailable: null,
    location: null,
    budget: null,
    preferences: [],
  });

  const { submitRoute, isLoading } = useRouteCreate();

  const totalSteps = 5;

  const updateFormData = (key: keyof FormData, value: any) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
  };

  const prepareApiRequest = () => {
    const today = new Date();
    const scheduledDate = today.toISOString().split("T")[0];
    const scheduledTime = "10:00";

    const apiRequest = {
      location: LOCATION_MAP[formData.location || "bishkek"],
      scheduledDate: scheduledDate,
      scheduledTime: scheduledTime,
      duration: TIME_MAP[formData.timeAvailable || "half-day"],
      mood:
        formData.preferences.length > 0 ? formData.preferences : ["relaxation"],
      budget: BUDGET_MAP[formData.budget || "medium"],
      companions: COMPANIONS_MAP[formData.companions || "alone"],
      transportation: TRANSPORT_MAP[formData.transportation || "walking"],
      mode: "quick" as const,
    };

    return apiRequest;
  };

  const handleNext = async () => {
    if (currentStep < totalSteps) {
      setCurrentStep((prev) => prev + 1);
    } else {
      try {
        const apiRequest = prepareApiRequest();
        console.log(JSON.stringify(apiRequest, null, 2));

        await submitRoute(apiRequest);
      } catch (error) {
        console.error(" Ошибка:", error);
        Alert.alert("Ошибка", "Не удалось создать маршрут. Попробуйте снова.", [
          { text: "OK" },
        ]);
      }
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep((prev) => prev - 1);
    } else {
      router.back();
    }
  };

  const renderStep = () => {
    const stepProps = {
      formData,
      updateFormData,
      onNext: handleNext,
    };

    switch (currentStep) {
      case 1:
        return <Step1WhoAndHow {...stepProps} />;
      case 2:
        return <Step2TimeAvailable {...stepProps} />;
      case 3:
        return <Step3Location {...stepProps} />;
      case 4:
        return <Step4Budget {...stepProps} />;
      case 5:
        return <Step5Preferences {...stepProps} />;
      default:
        return null;
    }
  };

  if (isLoading) {
    return (
      <View className="flex-1 bg-gray-50 items-center justify-center px-5">
        <ActivityIndicator size="large" color="#4A90E2" />
        <Text className="text-lg font-semibold text-gray-900 mt-4">
          Создаём маршрут...
        </Text>
        <Text className="text-sm text-gray-500 mt-2 text-center">
          AI подбирает идеальные места для вас
        </Text>
      </View>
    );
  }

  return (
    <View className="flex-1 bg-gray-50">
      <ProgressBar
        currentStep={currentStep}
        totalSteps={totalSteps}
        onBack={handleBack}
      />
      {renderStep()}
    </View>
  );
}
